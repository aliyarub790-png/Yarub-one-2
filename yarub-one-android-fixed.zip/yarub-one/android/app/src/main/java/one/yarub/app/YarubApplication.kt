package one.yarub.app

import android.app.Application

class YarubApplication : Application()
